.. _util_module:

:mod:`zktools.util`
===================

.. automodule:: zktools.util

.. autofunction:: safe_call
.. autofunction:: safe_create_ephemeral_sequence
.. autofunction:: threaded
